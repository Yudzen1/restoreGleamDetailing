Restore Gleam Detailing - Simple One Page Website

Files:
- index.html
- logo.png
- before1.jpg / after1.jpg ... before4.jpg / after4.jpg

How to publish FREE (GitHub Pages):
1) Create a GitHub account (if you don't have one)
2) Create a new repository named: restore-gleam-site
3) Upload all files from this folder
4) In the repo: Settings -> Pages -> Build and deployment -> Source: Deploy from a branch
5) Branch: main / root
6) Your site link will appear there.

If you want, paste your GitHub Pages link back to ChatGPT and we’ll optimize SEO text and add pricing.
